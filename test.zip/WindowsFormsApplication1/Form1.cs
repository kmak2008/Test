﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Net;
using System.Net.Mail;
using System.Runtime.InteropServices;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string UserNm = Environment.UserName;
     //   string cString = "Data Source=LACSQLCUSTDEV2;Initial Catalog=PASC;Integrated Security = SSPI;";

        string cString = ConfigurationManager.ConnectionStrings["PASC_DEV"].ConnectionString;

        SqlConnection cnn;
        SqlCommand cmd;
        SqlDataReader dataReader;
        string SQLStatement;

        string SQLStatement2;

        string SQLStatement3;

        SqlDataAdapter adap;
        DataSet ds;
        SqlCommandBuilder cmdbl;


        public Form1()
        {
            InitializeComponent();
        }
//Submit Intake Functions Below
        void FillCombo()  //function to fill combo box with LOB values from SQL Server DB
        {
            cnn = new SqlConnection(cString);

            SQLStatement = "select distinct LOB from pasc.UAT.MPSS_CAPITATION where USERNM='" + textBoxUserNm.Text + "';";

            try
            {
                cnn.Open();
                cmd = new SqlCommand(SQLStatement, cnn);
                dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    comboBoxLOB.Items.Add(dataReader[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR" + ex);
            }
            finally
            {
                dataReader.Close();
                cnn.Close();
            }
        }

        void IntakeNum()  //Function to provide latest Intake Number submitted (to display on message box) after email
        {
            SQLStatement2 = "select max(ID) from PASC.UAT.WinFormTest where USERLOGIN='" + textBoxUserNm.Text + "'";
            try
            {
                cnn.Open();

                cmd = new SqlCommand(SQLStatement2, cnn);
                dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    MessageBox.Show("Intake #" + dataReader.GetValue(0) + " is Submitted");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR" + ex);
            }
            finally
            {
                dataReader.Close();
                cmd.Dispose();
                cnn.Close();
            }
        }
        void UpdateNullPriorityLvl()  //Function to provide latest Intake Number submitted (to display on message box) after email
        {
            SQLStatement3 = "update PASC.UAT.WinFormTest set PRIORITY_LVL='LOW' where PRIORITY_LVL is null;";
            try
            {
                cnn.Open();
                cmd = new SqlCommand(SQLStatement3, cnn);
                dataReader = cmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR" + ex);
            }
            finally
            {
                dataReader.Close();
                cmd.Dispose();
                cnn.Close();
            }
        }
        void clearOutNewUserFrm()  //Function to clear out Submit Intake tab form
        {
            try
            {
                comboBoxLOB.Text = "";
                textBoxRqstTitle.Clear();
                textBoxRqstSum.Clear();
                Priority_comboBox.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void btnRecord_Click(object sender, EventArgs e)  //Function to insert new analyst request onto SQL Server DB
        {
            cnn = new SqlConnection(cString);

            SQLStatement = "insert into PASC.UAT.WinFormTest " +
                "select (select max(ID) from PASC.UAT.WinFormTest) + 1 ID" +
                ",ltrim(rtrim('" + textBoxUserNm.Text + "')) USERLOGIN" +
                ",'" + comboBoxLOB.Text + "' LOB" +
                ", getdate() REQUEST_DATE" +
                ",ltrim(rtrim('" + textBoxRqstTitle.Text + "')) REQUEST_TITLE" +
                ",replace(ltrim(rtrim('" + textBoxRqstSum.Text + "')),'''','^')  REQUEST_SUMMARY" +//Text.Replace("'","\'") 
                ",null FREQUENCY" +
                ",null DUE_DT" +
                ",'NEW' REQUEST_STATUS" +
                ",getdate() STATUS_DT" +
                ",null COMPLETED_DT" +
                ",null COMPLETED_BY" +
                ",null NOTES" +
                ",1 VIEWABLE" +
                ",'LOW' COMPLEXITY" +
                ",'" + Priority_comboBox.Text + "' PRIORITY_LVL";

            try
            {
                cnn.Open();
                cmd = new SqlCommand(SQLStatement, cnn);
                dataReader = cmd.ExecuteReader();
                dataReader.Close();
                cmd.Dispose();

                CreateMailItem();
                IntakeNum();
                clearOutNewUserFrm();
                UpdateNullPriorityLvl();

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR" + ex);
            }
            finally
            {
                cnn.Close();
            }
        }
        private void CreateMailItem()  //Function to send out email for new analyst request (SUBMIT INTAKE tab)
        {

            cnn = new SqlConnection(cString);
            SQLStatement2 = "select max(a.ID) MaxID,b.EMAIL from PASC.UAT.WinFormTest a with(nolock) " +
                            "left join (select distinct USERNM,FULLUSERNM,EMAIL from pasc.UAT.MPSS_CAPITATION (nolock)) b on b.USERNM=a.USERLOGIN " +
                            "where USERLOGIN='" + textBoxUserNm.Text + "' group by b.EMAIL";
            cnn.Open();
            cmd = new SqlCommand(SQLStatement2, cnn);
            dataReader = cmd.ExecuteReader();

            try
            {
                while (dataReader.Read())
                {
                    Outlook.Application app = new Outlook.Application();
                    Outlook.MailItem mailItem = app.CreateItem(Outlook.OlItemType.olMailItem);
                    mailItem.Subject = "Intake #" + dataReader.GetValue(0) + " - " + textBoxRqstTitle.Text + " - " + Priority_comboBox.Text;
                    mailItem.To = "kkao@lacare.org;" + dataReader.GetValue(1);
                    mailItem.Body = "REQUEST SUMMARY:" + "\n" + textBoxRqstSum.Text;
                    mailItem.Importance = Outlook.OlImportance.olImportanceLow;
                    mailItem.Display(true);
                    // mailItem.Send();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR" + ex);
            }
            finally
            {
                dataReader.Close();
                cmd.Dispose();
                cnn.Close();
            }
        }

        //Intake List Functions Below
        private void Form1_Load(object sender, EventArgs e)  //Function to have form preload with intake submissions on Intake List tab
        {

            cnn = new SqlConnection(cString);

            textBoxUserNm.Text = UserNm;

            if (UserNm == "martham" || UserNm == "kevinkao")
            {
                SQLStatement = "SELECT ID,USERLOGIN, LOB, REQUEST_DATE, REQUEST_TITLE, REQUEST_SUMMARY, REQUEST_STATUS, COMPLETED_DT, PRIORITY_LVL FROM pasc.UAT.WinFormTest ORDER BY REQUEST_DATE DESC";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                cnn.Open();

                try
                {
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    textBoxRqstDtTm.Text = DateTime.Now.ToShortDateString();
                    FillCombo();

                    comboBoxLOB.Select();

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else
            {
                tabSubmit.TabPages.Remove(tabPage3);

                SQLStatement = "SELECT ID,USERLOGIN, LOB, REQUEST_DATE, REQUEST_TITLE, REQUEST_SUMMARY, REQUEST_STATUS, COMPLETED_DT, PRIORITY_LVL FROM pasc.UAT.WinFormTest where USERLOGIN = '" + textBoxUserNm.Text + "' ORDER BY REQUEST_DATE DESC";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                cnn.Open();

                try
                {
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    textBoxRqstDtTm.Text = DateTime.Now.ToShortDateString();
                    FillCombo();

                    comboBoxLOB.Select();

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
        }

        private void buttonRefresh_Click(object sender, EventArgs e)  //Function for refreshing Intake List tab (using date parameters)
        {
            cnn = new SqlConnection(cString);

            if (UserNm == "martham" || UserNm == "kevinkao")
            {
                SQLStatement = "SELECT COMPLETED_DT, ID, LOB, REQUEST_DATE, REQUEST_STATUS, REQUEST_SUMMARY, REQUEST_TITLE, USERLOGIN, PRIORITY_LVL FROM pasc.UAT.WinFormTest WHERE cast(request_date as date) between '" + DateTime.Parse(dateTimePicker1.Text) + "' and '" + DateTime.Parse(dateTimePicker2.Text) + "' ORDER BY REQUEST_DATE DESC;";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                try
                {
                    cnn.Open();
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
                    dataGridView1.Columns[5].Width = 205;
                    dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else
            {
                SQLStatement = "SELECT COMPLETED_DT, ID, LOB, REQUEST_DATE, REQUEST_STATUS, REQUEST_SUMMARY, REQUEST_TITLE, USERLOGIN, PRIORITY_LVL FROM pasc.UAT.WinFormTest WHERE cast(request_date as date) between '" + DateTime.Parse(dateTimePicker1.Text) + "' and '" + DateTime.Parse(dateTimePicker2.Text) + "' and USERLOGIN = '" + textBoxUserNm.Text + "' ORDER BY REQUEST_DATE DESC;";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                try
                {
                    cnn.Open();
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
                    dataGridView1.Columns[5].Width = 205;
                    dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
        }

        private void buttonSaveChanges_Click(object sender, EventArgs e)  //Function to save changes made on INTAKE LIST tab
        {
            cnn = new SqlConnection(cString);
            cnn.Open();

            try
            {
                cmdbl = new SqlCommandBuilder(adap);
                adap.Update(ds, "User_Details");
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Update failed - " + ex);
            }
            finally
            {
                cnn.Close();
            }
        }

        private void CompletedCheckBox_CheckedChanged(object sender, EventArgs e)  //Function to sort completed vs incomplete intake items on Intake List tab
        {
            cnn = new SqlConnection(cString);

            if ((UserNm == "martham" && CompletedCheckBox.Checked == true) || (UserNm == "kevinkao" && CompletedCheckBox.Checked == true))
            {

                SQLStatement = "SELECT COMPLETED_DT, ID, LOB, REQUEST_DATE, REQUEST_STATUS, REQUEST_SUMMARY, REQUEST_TITLE, USERLOGIN, PRIORITY_LVL FROM pasc.UAT.WinFormTest WHERE Completed_Dt is not null and cast(request_date as date) between '" + DateTime.Parse(dateTimePicker1.Text) + "' and '" + DateTime.Parse(dateTimePicker2.Text) + "' ORDER BY REQUEST_DATE DESC;";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                try
                {
                    cnn.Open();
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
                    dataGridView1.Columns[5].Width = 205;
                    dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else if ((UserNm == "martham" && CompletedCheckBox.Checked == false) || (UserNm == "kevinkao" && CompletedCheckBox.Checked == false))
            {
                SQLStatement = "SELECT COMPLETED_DT, ID, LOB, REQUEST_DATE, REQUEST_STATUS, REQUEST_SUMMARY, REQUEST_TITLE, USERLOGIN, PRIORITY_LVL FROM pasc.UAT.WinFormTest WHERE Completed_Dt is null and cast(request_date as date) between '" + DateTime.Parse(dateTimePicker1.Text) + "' and '" + DateTime.Parse(dateTimePicker2.Text) + "' ORDER BY REQUEST_DATE DESC;";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                try
                {
                    cnn.Open();
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
                    dataGridView1.Columns[5].Width = 205;
                    dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else if ((UserNm != "martham" && CompletedCheckBox.Checked == true) || (UserNm != "kevinkao" && CompletedCheckBox.Checked == true))
            {
                SQLStatement = "SELECT COMPLETED_DT, ID, LOB, REQUEST_DATE, REQUEST_STATUS, REQUEST_SUMMARY, REQUEST_TITLE, USERLOGIN, PRIORITY_LVL FROM pasc.UAT.WinFormTest WHERE Completed_Dt is not null and cast(request_date as date) between '" + DateTime.Parse(dateTimePicker1.Text) + "' and '" + DateTime.Parse(dateTimePicker2.Text) + "' and USERLOGIN = '" + textBoxUserNm.Text + "' ORDER BY REQUEST_DATE DESC;";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                try
                {
                    cnn.Open();
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
                    dataGridView1.Columns[5].Width = 205;
                    dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else if ((UserNm != "martham" && CompletedCheckBox.Checked == false) || (UserNm != "kevinkao" && CompletedCheckBox.Checked == false))
            {
                SQLStatement = "SELECT COMPLETED_DT, ID, LOB, REQUEST_DATE, REQUEST_STATUS, REQUEST_SUMMARY, REQUEST_TITLE, USERLOGIN, PRIORITY_LVL FROM pasc.UAT.WinFormTest WHERE Completed_Dt is null and cast(request_date as date) between '" + DateTime.Parse(dateTimePicker1.Text) + "' and '" + DateTime.Parse(dateTimePicker2.Text) + "' and USERLOGIN = '" + textBoxUserNm.Text + "' ORDER BY REQUEST_DATE DESC;";

                adap = new SqlDataAdapter(SQLStatement, cnn);
                ds = new DataSet();

                try
                {
                    cnn.Open();
                    adap.Fill(ds, "User_Details");

                    dataGridView1.DataSource = ds.Tables[0];

                    dataGridView1.AutoResizeColumns();
                    dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
                    dataGridView1.Columns[5].Width = 205;
                    dataGridView1.Columns[5].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                    dataGridView1.AutoResizeRows();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
                finally
                {
                    cnn.Close();
                }
            }
        }

//Programmer WS Functions Below
        void clearOutReq()  //Function to Clear Out Programmer Worksheet
        {
            try
            {
                ReqSearchID_textBox.Clear();
                ReviewUserNm_textBox.Clear();
                ReqLOB_textBox.Clear();
                ReviewUserReqTitle_textBox.Clear();
                ReqUserDT_textBox.Clear();
                ReviewReqSum_textBox.Clear();
                ReqSearchStatus_comboBox.Text = "";
                RequestStatus_dateTimePicker.Text = "";
                ReqCompleted_comboBox.Text = "";
                ReqComplDt_TextBox.Clear();
                ReqView_checkBox.Checked = Boolean.Parse("false");
                ReqNotes_textBox.Clear();
                ReqPrior_comboBox.Text = "";
                ReqComplex_comboBox.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

    private void ReqSearch_button_Click(object sender, EventArgs e)  //Function to search by ID on Programmer Worksheet
    {
        cnn = new SqlConnection(cString);

        SQLStatement = "SELECT ID, USERLOGIN, LOB, REQUEST_TITLE, REQUEST_DATE, REQUEST_SUMMARY, REQUEST_STATUS, STATUS_DT, COMPLETED_BY, COMPLETED_DT, VIEWABLE, NOTES, PRIORITY_LVL, COMPLEXITY FROM pasc.UAT.WinFormTest WHERE ID=" + ReqSearchID_textBox.Text + ";";

        try
        {
            if (ReqComplDt_TextBox.Text == "" && ReviewUserNm_textBox.Text == "" && ReqSearchID_textBox.Text == "")
            {
                MessageBox.Show("INVALID!!  Must enter valid ID number!!");
            }
            else
            { 
                cnn.Open();
                cmd = new SqlCommand(SQLStatement, cnn);
                dataReader = cmd.ExecuteReader();

                while (dataReader.Read())
                {
                    ReviewUserNm_textBox.Text = dataReader[1].ToString();
                    ReqLOB_textBox.Text = dataReader[2].ToString();
                    ReviewUserReqTitle_textBox.Text = dataReader[3].ToString();
                    ReqUserDT_textBox.Text = dataReader[4].ToString();
                    ReviewReqSum_textBox.Text = dataReader[5].ToString();
                    ReqSearchStatus_comboBox.Text = dataReader[6].ToString();
                    RequestStatus_dateTimePicker.Text = dataReader[7].ToString();
                    ReqCompleted_comboBox.Text = dataReader[8].ToString();
                    ReqComplDt_TextBox.Text = dataReader[9].ToString();
                    ReqView_checkBox.Checked = Boolean.Parse(dataReader[10].ToString());
                    ReqNotes_textBox.Text = dataReader[11].ToString();
                    ReqPrior_comboBox.Text = dataReader[12].ToString();
                    ReqComplex_comboBox.Text = dataReader[13].ToString();
                    }
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error" + ex);
        }
        finally
        {
            cnn.Close();
        }
    }

    private void CreateMailItem2()  //Function to send out email from Programmer Worksheet
    {

        cnn = new SqlConnection(cString);
        SQLStatement2 = "select a.ID,b.EMAIL,a.REQUEST_STATUS,a.REQUEST_TITLE,a.REQUEST_SUMMARY,a.NOTES,a.COMPLETED_BY,a.COMPLETED_DT,a.PRIORITY_LVL,a.COMPLEXITY from PASC.UAT.WinFormTest a with(nolock) " +
                        "left join (select distinct USERNM,FULLUSERNM,EMAIL from pasc.UAT.MPSS_CAPITATION (nolock)) b on b.USERNM=a.USERLOGIN " +
                        "where ID=" + int.Parse(ReqSearchID_textBox.Text) +";" ;
        cnn.Open();

        cmd = new SqlCommand(SQLStatement2, cnn);
        dataReader = cmd.ExecuteReader();

        try
        {
            while (dataReader.Read())
            {
                Outlook.Application app = new Outlook.Application();
                Outlook.MailItem mailItem = app.CreateItem(Outlook.OlItemType.olMailItem);
                mailItem.Subject = dataReader.GetValue(2) + " - Intake #" + dataReader.GetValue(0) + " - " + dataReader.GetValue(3) + " - " + dataReader.GetValue(8);
                mailItem.To = "kkao@lacare.org;" + dataReader.GetValue(1);
                mailItem.Body = "REQUEST SUMMARY:" + "\n" + dataReader.GetValue(4) + "\n" + "\n" + "STATUS NOTES:" + "\n" + dataReader.GetValue(5) + "\n" + "\n" + "Completed by:" + dataReader.GetValue(6) + "; Completed Date/Time" + dataReader.GetValue(7) +
                                    "\n" + "\n" + "Priority: " + dataReader.GetValue(8) + "; Complexity: " + dataReader.GetValue(9);
                mailItem.Importance = Outlook.OlImportance.olImportanceLow;
                mailItem.Display(true);
                // mailItem.Send();
            }
            clearOutReq();
        }
        catch (Exception ex)
        {
            MessageBox.Show("ERROR" + ex);
        }
        finally
        {
            dataReader.Close();
            cmd.Dispose();
            cnn.Close();
        }
    }
    private void ReqSave_button_Click(object sender, EventArgs e)  //Function to save on Programmer Worksheet
    {
        cnn = new SqlConnection(cString);

        if (ReqComplDt_TextBox.Text == "" && ReviewUserNm_textBox.Text != "") //If completed dt is blank and UserLogin is not blank
        {
            SQLStatement = "update PASC.UAT.WinFormTest " +
            "SET USERLOGIN ='" + ReviewUserNm_textBox.Text + "'" +
            ",LOB ='" + ReqLOB_textBox.Text + "'" +
            ",REQUEST_TITLE ='" + ReviewUserReqTitle_textBox.Text + "'" +
            ",REQUEST_DATE ='" + DateTime.Parse(ReqUserDT_textBox.Text) + "'" +
            ",REQUEST_SUMMARY ='" + ReviewReqSum_textBox.Text + "'" +
            ",REQUEST_STATUS ='" + ReqSearchStatus_comboBox.Text + "'" +
            ",STATUS_DT ='" + DateTime.Parse(RequestStatus_dateTimePicker.Text) + "'" +
            ",COMPLETED_BY ='" + ReqCompleted_comboBox.Text + "'" +
            ",COMPLETED_DT = NULL"+
            ",NOTES = '" + ReqNotes_textBox.Text + "' " +
            ",VIEWABLE ='" + Convert.ToByte(ReqView_checkBox.Checked) + "'" +
            ",COMPLEXITY ='" + ReqComplex_comboBox.Text + "'" +
            ",PRIORITY_LVL ='" + ReqPrior_comboBox.Text + "'" +
            "where ID =" + int.Parse(ReqSearchID_textBox.Text) + ";";
        }
        else if (ReqComplDt_TextBox.Text == "" && ReviewUserNm_textBox.Text == "")  //If completed dt is blank and UserLogin is blank
        {
            MessageBox.Show("Invalid Option - Cannot save blank records!!");
        }
        else if (ReqComplDt_TextBox.Text != "" && ReviewUserNm_textBox.Text != "") //If Completed dt is not blank and UserLogin is not blank
        {
            SQLStatement = "update PASC.UAT.WinFormTest " +
            "SET USERLOGIN ='" + ReviewUserNm_textBox.Text + "'" +
            ",LOB ='" + ReqLOB_textBox.Text + "'" +
            ",REQUEST_TITLE ='" + ReviewUserReqTitle_textBox.Text + "'" +
            ",REQUEST_DATE ='" + DateTime.Parse(ReqUserDT_textBox.Text) + "'" +
            ",REQUEST_SUMMARY ='" + ReviewReqSum_textBox.Text + "'" +
            ",REQUEST_STATUS ='" + ReqSearchStatus_comboBox.Text + "'" +
            ",STATUS_DT ='" + DateTime.Parse(RequestStatus_dateTimePicker.Text) + "'" +
            ",COMPLETED_BY ='" + ReqCompleted_comboBox.Text + "'" +
            ",COMPLETED_DT ='" + DateTime.Parse(ReqComplDt_TextBox.Text) + "'" +
//            ",COMPLETED_DT ='" + DateTime.ParseExact(ReqComplDt_TextBox.Text, LongDateFormat, provider) + "'" +
            ",NOTES = '" + ReqNotes_textBox.Text + "' " +
            ",VIEWABLE ='" + Convert.ToByte(ReqView_checkBox.Checked) + "'" +
            ",COMPLEXITY ='" + ReqComplex_comboBox.Text + "'" +
            ",PRIORITY_LVL ='" + ReqPrior_comboBox.Text + "'" +
            "where ID =" + int.Parse(ReqSearchID_textBox.Text) + ";";
        }
            /*          string Command = "update PASC.UAT.WinFormTest " +
                        "SET USERLOGIN=@ReviewUserNm_textBox" +
                        ",LOB=@ReqLOB_textBox" + 
                        ",REQUEST_TITLE=@ReviewUserReqTitle_textBox" + 
                        ",REQUEST_DATE=@ReviewUserReqTitle_textBox" + 
                        ",REQUEST_SUMMARY=@ReviewReqSum_textBox" + 
                        ",REQUEST_STATUS=@ReqSearchStatus_comboBox" + 
                        ",STATUS_DT=@RequestStatus_dateTimePicker" + 
                        ",COMPLETED_BY=@ReqCompleted_comboBox" + 
                        ",COMPLETED_DT=@ReqComplDt_TextBox" + 
                        ",NOTES=@ReqNotes_textBox " + 
                        ",VIEWABLE=@ReqView_checkBox"
                        "where ID=@ReqSearchID_textBox"; 
            */
            try
            {
                if (ReqComplDt_TextBox.Text == "" && ReviewUserNm_textBox.Text == "")  //if completed dt is blank and UserLogin is blank
                {  }
                else
                {
                    cnn.Open();

                    cmd = new SqlCommand(SQLStatement, cnn);
                    dataReader = cmd.ExecuteReader();

                    dataReader.Close();
                    cmd.Dispose();

                    cnn.Close();

                    CreateMailItem2();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void ClearOutReq_button_Click(object sender, EventArgs e)
        {
            clearOutReq();
        }

        private void ReqStatusDt_pictureBox_Click(object sender, EventArgs e)
        {
            RequestStatus_dateTimePicker.Text = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss tt");
        }

        private void ReqComplDt_pictureBox_Click(object sender, EventArgs e)
        {
            ReqComplDt_TextBox.Text = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss tt");
        }
    }
}
