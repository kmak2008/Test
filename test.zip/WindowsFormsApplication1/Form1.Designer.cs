﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRecord = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabSubmit = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxRqstSum = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxRqstTitle = new System.Windows.Forms.TextBox();
            this.comboBoxLOB = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.UserNmLabel = new System.Windows.Forms.Label();
            this.textBoxUserNm = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.buttonSaveChanges = new System.Windows.Forms.Button();
            this.CompletedCheckBox = new System.Windows.Forms.CheckBox();
            this.buttonRefresh = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.ReqCompleted_comboBox = new System.Windows.Forms.ComboBox();
            this.ReqSearchStatus_comboBox = new System.Windows.Forms.ComboBox();
            this.ReqComplDt_pictureBox = new System.Windows.Forms.PictureBox();
            this.ReqStatusDt_pictureBox = new System.Windows.Forms.PictureBox();
            this.ClearOutReq_button = new System.Windows.Forms.Button();
            this.ReqComplDt_TextBox = new System.Windows.Forms.TextBox();
            this.ReqUserDT_textBox = new System.Windows.Forms.TextBox();
            this.ReqView_checkBox = new System.Windows.Forms.CheckBox();
            this.ReqSave_button = new System.Windows.Forms.Button();
            this.ReqSearch_button = new System.Windows.Forms.Button();
            this.RequestStatus_label = new System.Windows.Forms.Label();
            this.RequestStatus_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ReqSearchStatus_label = new System.Windows.Forms.Label();
            this.SearchbyID_label = new System.Windows.Forms.Label();
            this.ReqSearchID_textBox = new System.Windows.Forms.TextBox();
            this.ReqComplDt_label = new System.Windows.Forms.Label();
            this.ReqNotes_label = new System.Windows.Forms.Label();
            this.ReqNotes_textBox = new System.Windows.Forms.TextBox();
            this.ReqCompleted_label = new System.Windows.Forms.Label();
            this.ReqLOB_textBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ReviewReqSum_textBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ReviewUserReqTitle_textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ReviewUserNm_textBox = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBoxRqstDtTm = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Priority_comboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.ReqComplex_comboBox = new System.Windows.Forms.ComboBox();
            this.ReqPrior_comboBox = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabSubmit.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ReqComplDt_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReqStatusDt_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRecord
            // 
            this.btnRecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecord.Location = new System.Drawing.Point(21, 428);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(893, 71);
            this.btnRecord.TabIndex = 3;
            this.btnRecord.Text = "RECORD";
            this.btnRecord.UseVisualStyleBackColor = true;
            this.btnRecord.Click += new System.EventHandler(this.btnRecord_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(140, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(492, 40);
            this.label1.TabIndex = 9;
            this.label1.Text = "MPSS Capitation - Intake App";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(826, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Current Date";
            // 
            // tabSubmit
            // 
            this.tabSubmit.Controls.Add(this.tabPage1);
            this.tabSubmit.Controls.Add(this.tabPage2);
            this.tabSubmit.Controls.Add(this.tabPage3);
            this.tabSubmit.Controls.Add(this.tabPage4);
            this.tabSubmit.Location = new System.Drawing.Point(25, 89);
            this.tabSubmit.Name = "tabSubmit";
            this.tabSubmit.SelectedIndex = 0;
            this.tabSubmit.Size = new System.Drawing.Size(949, 544);
            this.tabSubmit.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.Priority_comboBox);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textBoxRqstSum);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.textBoxRqstTitle);
            this.tabPage1.Controls.Add(this.comboBoxLOB);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.UserNmLabel);
            this.tabPage1.Controls.Add(this.btnRecord);
            this.tabPage1.Controls.Add(this.textBoxUserNm);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(941, 518);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SUBMIT INTAKE";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Request Summary";
            // 
            // textBoxRqstSum
            // 
            this.textBoxRqstSum.Location = new System.Drawing.Point(21, 72);
            this.textBoxRqstSum.Multiline = true;
            this.textBoxRqstSum.Name = "textBoxRqstSum";
            this.textBoxRqstSum.Size = new System.Drawing.Size(893, 332);
            this.textBoxRqstSum.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(472, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Request Title";
            // 
            // textBoxRqstTitle
            // 
            this.textBoxRqstTitle.Location = new System.Drawing.Point(561, 11);
            this.textBoxRqstTitle.Name = "textBoxRqstTitle";
            this.textBoxRqstTitle.Size = new System.Drawing.Size(353, 20);
            this.textBoxRqstTitle.TabIndex = 14;
            // 
            // comboBoxLOB
            // 
            this.comboBoxLOB.FormattingEnabled = true;
            this.comboBoxLOB.Location = new System.Drawing.Point(329, 11);
            this.comboBoxLOB.Name = "comboBoxLOB";
            this.comboBoxLOB.Size = new System.Drawing.Size(110, 21);
            this.comboBoxLOB.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(295, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "LOB";
            // 
            // UserNmLabel
            // 
            this.UserNmLabel.AutoSize = true;
            this.UserNmLabel.Location = new System.Drawing.Point(18, 14);
            this.UserNmLabel.Name = "UserNmLabel";
            this.UserNmLabel.Size = new System.Drawing.Size(89, 13);
            this.UserNmLabel.TabIndex = 4;
            this.UserNmLabel.Text = "User Login Name";
            // 
            // textBoxUserNm
            // 
            this.textBoxUserNm.Location = new System.Drawing.Point(129, 10);
            this.textBoxUserNm.Name = "textBoxUserNm";
            this.textBoxUserNm.Size = new System.Drawing.Size(145, 20);
            this.textBoxUserNm.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.buttonSaveChanges);
            this.tabPage2.Controls.Add(this.CompletedCheckBox);
            this.tabPage2.Controls.Add(this.buttonRefresh);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.dateTimePicker2);
            this.tabPage2.Controls.Add(this.dateTimePicker1);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(941, 518);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "INTAKE LIST";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(935, 459);
            this.dataGridView1.TabIndex = 9;
            // 
            // buttonSaveChanges
            // 
            this.buttonSaveChanges.Location = new System.Drawing.Point(619, 13);
            this.buttonSaveChanges.Name = "buttonSaveChanges";
            this.buttonSaveChanges.Size = new System.Drawing.Size(78, 34);
            this.buttonSaveChanges.TabIndex = 8;
            this.buttonSaveChanges.Text = "SAVE CHANGES";
            this.buttonSaveChanges.UseVisualStyleBackColor = true;
            this.buttonSaveChanges.Click += new System.EventHandler(this.buttonSaveChanges_Click);
            // 
            // CompletedCheckBox
            // 
            this.CompletedCheckBox.AutoSize = true;
            this.CompletedCheckBox.Location = new System.Drawing.Point(821, 13);
            this.CompletedCheckBox.Name = "CompletedCheckBox";
            this.CompletedCheckBox.Size = new System.Drawing.Size(114, 17);
            this.CompletedCheckBox.TabIndex = 6;
            this.CompletedCheckBox.Text = "Completed Intakes";
            this.CompletedCheckBox.UseVisualStyleBackColor = true;
            this.CompletedCheckBox.CheckedChanged += new System.EventHandler(this.CompletedCheckBox_CheckedChanged);
            // 
            // buttonRefresh
            // 
            this.buttonRefresh.Location = new System.Drawing.Point(528, 13);
            this.buttonRefresh.Name = "buttonRefresh";
            this.buttonRefresh.Size = new System.Drawing.Size(75, 34);
            this.buttonRefresh.TabIndex = 5;
            this.buttonRefresh.Text = "REFRESH";
            this.buttonRefresh.UseVisualStyleBackColor = true;
            this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(264, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "Request Date To:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Request Date From:";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(362, 16);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker2.TabIndex = 2;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "MM/dd/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(127, 16);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.ReqPrior_comboBox);
            this.tabPage3.Controls.Add(this.ReqComplex_comboBox);
            this.tabPage3.Controls.Add(this.ReqCompleted_comboBox);
            this.tabPage3.Controls.Add(this.ReqSearchStatus_comboBox);
            this.tabPage3.Controls.Add(this.ReqComplDt_pictureBox);
            this.tabPage3.Controls.Add(this.ReqStatusDt_pictureBox);
            this.tabPage3.Controls.Add(this.ClearOutReq_button);
            this.tabPage3.Controls.Add(this.ReqComplDt_TextBox);
            this.tabPage3.Controls.Add(this.ReqUserDT_textBox);
            this.tabPage3.Controls.Add(this.ReqView_checkBox);
            this.tabPage3.Controls.Add(this.ReqSave_button);
            this.tabPage3.Controls.Add(this.ReqSearch_button);
            this.tabPage3.Controls.Add(this.RequestStatus_label);
            this.tabPage3.Controls.Add(this.RequestStatus_dateTimePicker);
            this.tabPage3.Controls.Add(this.ReqSearchStatus_label);
            this.tabPage3.Controls.Add(this.SearchbyID_label);
            this.tabPage3.Controls.Add(this.ReqSearchID_textBox);
            this.tabPage3.Controls.Add(this.ReqComplDt_label);
            this.tabPage3.Controls.Add(this.ReqNotes_label);
            this.tabPage3.Controls.Add(this.ReqNotes_textBox);
            this.tabPage3.Controls.Add(this.ReqCompleted_label);
            this.tabPage3.Controls.Add(this.ReqLOB_textBox);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.ReviewReqSum_textBox);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.ReviewUserReqTitle_textBox);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.ReviewUserNm_textBox);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(941, 518);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Programmer WS";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // ReqCompleted_comboBox
            // 
            this.ReqCompleted_comboBox.FormattingEnabled = true;
            this.ReqCompleted_comboBox.Items.AddRange(new object[] {
            "",
            "kevinkao"});
            this.ReqCompleted_comboBox.Location = new System.Drawing.Point(623, 131);
            this.ReqCompleted_comboBox.Name = "ReqCompleted_comboBox";
            this.ReqCompleted_comboBox.Size = new System.Drawing.Size(117, 21);
            this.ReqCompleted_comboBox.TabIndex = 50;
            // 
            // ReqSearchStatus_comboBox
            // 
            this.ReqSearchStatus_comboBox.FormattingEnabled = true;
            this.ReqSearchStatus_comboBox.Items.AddRange(new object[] {
            "",
            "NEW",
            "IN PROGRESS",
            "COMPLETED",
            "IMPEDED",
            "CANCELED"});
            this.ReqSearchStatus_comboBox.Location = new System.Drawing.Point(623, 61);
            this.ReqSearchStatus_comboBox.Name = "ReqSearchStatus_comboBox";
            this.ReqSearchStatus_comboBox.Size = new System.Drawing.Size(164, 21);
            this.ReqSearchStatus_comboBox.TabIndex = 49;
            // 
            // ReqComplDt_pictureBox
            // 
            this.ReqComplDt_pictureBox.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Refresh1;
            this.ReqComplDt_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ReqComplDt_pictureBox.Location = new System.Drawing.Point(793, 163);
            this.ReqComplDt_pictureBox.Name = "ReqComplDt_pictureBox";
            this.ReqComplDt_pictureBox.Size = new System.Drawing.Size(25, 20);
            this.ReqComplDt_pictureBox.TabIndex = 48;
            this.ReqComplDt_pictureBox.TabStop = false;
            this.ReqComplDt_pictureBox.Click += new System.EventHandler(this.ReqComplDt_pictureBox_Click);
            // 
            // ReqStatusDt_pictureBox
            // 
            this.ReqStatusDt_pictureBox.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Refresh1;
            this.ReqStatusDt_pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ReqStatusDt_pictureBox.Location = new System.Drawing.Point(793, 97);
            this.ReqStatusDt_pictureBox.Name = "ReqStatusDt_pictureBox";
            this.ReqStatusDt_pictureBox.Size = new System.Drawing.Size(25, 20);
            this.ReqStatusDt_pictureBox.TabIndex = 47;
            this.ReqStatusDt_pictureBox.TabStop = false;
            this.ReqStatusDt_pictureBox.Click += new System.EventHandler(this.ReqStatusDt_pictureBox_Click);
            // 
            // ClearOutReq_button
            // 
            this.ClearOutReq_button.Location = new System.Drawing.Point(332, 13);
            this.ClearOutReq_button.Name = "ClearOutReq_button";
            this.ClearOutReq_button.Size = new System.Drawing.Size(75, 34);
            this.ClearOutReq_button.TabIndex = 46;
            this.ClearOutReq_button.Text = "CLEAR";
            this.ClearOutReq_button.UseVisualStyleBackColor = true;
            this.ClearOutReq_button.Click += new System.EventHandler(this.ClearOutReq_button_Click);
            // 
            // ReqComplDt_TextBox
            // 
            this.ReqComplDt_TextBox.Location = new System.Drawing.Point(623, 163);
            this.ReqComplDt_TextBox.Name = "ReqComplDt_TextBox";
            this.ReqComplDt_TextBox.Size = new System.Drawing.Size(164, 20);
            this.ReqComplDt_TextBox.TabIndex = 45;
            // 
            // ReqUserDT_textBox
            // 
            this.ReqUserDT_textBox.Location = new System.Drawing.Point(132, 132);
            this.ReqUserDT_textBox.Name = "ReqUserDT_textBox";
            this.ReqUserDT_textBox.Size = new System.Drawing.Size(145, 20);
            this.ReqUserDT_textBox.TabIndex = 44;
            // 
            // ReqView_checkBox
            // 
            this.ReqView_checkBox.AutoSize = true;
            this.ReqView_checkBox.CheckAlign = System.Drawing.ContentAlignment.BottomRight;
            this.ReqView_checkBox.Location = new System.Drawing.Point(845, 166);
            this.ReqView_checkBox.Name = "ReqView_checkBox";
            this.ReqView_checkBox.Size = new System.Drawing.Size(69, 17);
            this.ReqView_checkBox.TabIndex = 43;
            this.ReqView_checkBox.Text = "Viewable";
            this.ReqView_checkBox.UseVisualStyleBackColor = true;
            // 
            // ReqSave_button
            // 
            this.ReqSave_button.Location = new System.Drawing.Point(800, 13);
            this.ReqSave_button.Name = "ReqSave_button";
            this.ReqSave_button.Size = new System.Drawing.Size(78, 34);
            this.ReqSave_button.TabIndex = 42;
            this.ReqSave_button.Text = "SAVE CHANGES";
            this.ReqSave_button.UseVisualStyleBackColor = true;
            this.ReqSave_button.Click += new System.EventHandler(this.ReqSave_button_Click);
            // 
            // ReqSearch_button
            // 
            this.ReqSearch_button.Location = new System.Drawing.Point(234, 14);
            this.ReqSearch_button.Name = "ReqSearch_button";
            this.ReqSearch_button.Size = new System.Drawing.Size(75, 34);
            this.ReqSearch_button.TabIndex = 41;
            this.ReqSearch_button.Text = "SEARCH";
            this.ReqSearch_button.UseVisualStyleBackColor = true;
            this.ReqSearch_button.Click += new System.EventHandler(this.ReqSearch_button_Click);
            // 
            // RequestStatus_label
            // 
            this.RequestStatus_label.AutoSize = true;
            this.RequestStatus_label.Location = new System.Drawing.Point(527, 103);
            this.RequestStatus_label.Name = "RequestStatus_label";
            this.RequestStatus_label.Size = new System.Drawing.Size(66, 13);
            this.RequestStatus_label.TabIndex = 40;
            this.RequestStatus_label.Text = "Status Date:";
            // 
            // RequestStatus_dateTimePicker
            // 
            this.RequestStatus_dateTimePicker.CustomFormat = "MM/dd/yyyy HH:mm:ss tt";
            this.RequestStatus_dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.RequestStatus_dateTimePicker.Location = new System.Drawing.Point(623, 97);
            this.RequestStatus_dateTimePicker.Name = "RequestStatus_dateTimePicker";
            this.RequestStatus_dateTimePicker.Size = new System.Drawing.Size(164, 20);
            this.RequestStatus_dateTimePicker.TabIndex = 39;
            // 
            // ReqSearchStatus_label
            // 
            this.ReqSearchStatus_label.AutoSize = true;
            this.ReqSearchStatus_label.Location = new System.Drawing.Point(528, 66);
            this.ReqSearchStatus_label.Name = "ReqSearchStatus_label";
            this.ReqSearchStatus_label.Size = new System.Drawing.Size(80, 13);
            this.ReqSearchStatus_label.TabIndex = 38;
            this.ReqSearchStatus_label.Text = "Request Status";
            // 
            // SearchbyID_label
            // 
            this.SearchbyID_label.AutoSize = true;
            this.SearchbyID_label.Location = new System.Drawing.Point(21, 25);
            this.SearchbyID_label.Name = "SearchbyID_label";
            this.SearchbyID_label.Size = new System.Drawing.Size(69, 13);
            this.SearchbyID_label.TabIndex = 36;
            this.SearchbyID_label.Text = "Search by ID";
            // 
            // ReqSearchID_textBox
            // 
            this.ReqSearchID_textBox.Location = new System.Drawing.Point(132, 21);
            this.ReqSearchID_textBox.Name = "ReqSearchID_textBox";
            this.ReqSearchID_textBox.Size = new System.Drawing.Size(66, 20);
            this.ReqSearchID_textBox.TabIndex = 35;
            // 
            // ReqComplDt_label
            // 
            this.ReqComplDt_label.AutoSize = true;
            this.ReqComplDt_label.Location = new System.Drawing.Point(527, 166);
            this.ReqComplDt_label.Name = "ReqComplDt_label";
            this.ReqComplDt_label.Size = new System.Drawing.Size(86, 13);
            this.ReqComplDt_label.TabIndex = 34;
            this.ReqComplDt_label.Text = "Completed Date:";
            // 
            // ReqNotes_label
            // 
            this.ReqNotes_label.AutoSize = true;
            this.ReqNotes_label.Location = new System.Drawing.Point(528, 192);
            this.ReqNotes_label.Name = "ReqNotes_label";
            this.ReqNotes_label.Size = new System.Drawing.Size(35, 13);
            this.ReqNotes_label.TabIndex = 32;
            this.ReqNotes_label.Text = "Notes";
            // 
            // ReqNotes_textBox
            // 
            this.ReqNotes_textBox.Location = new System.Drawing.Point(531, 208);
            this.ReqNotes_textBox.Multiline = true;
            this.ReqNotes_textBox.Name = "ReqNotes_textBox";
            this.ReqNotes_textBox.Size = new System.Drawing.Size(383, 254);
            this.ReqNotes_textBox.TabIndex = 31;
            // 
            // ReqCompleted_label
            // 
            this.ReqCompleted_label.AutoSize = true;
            this.ReqCompleted_label.Location = new System.Drawing.Point(527, 135);
            this.ReqCompleted_label.Name = "ReqCompleted_label";
            this.ReqCompleted_label.Size = new System.Drawing.Size(72, 13);
            this.ReqCompleted_label.TabIndex = 30;
            this.ReqCompleted_label.Text = "Completed By";
            // 
            // ReqLOB_textBox
            // 
            this.ReqLOB_textBox.Location = new System.Drawing.Point(332, 63);
            this.ReqLOB_textBox.Name = "ReqLOB_textBox";
            this.ReqLOB_textBox.Size = new System.Drawing.Size(97, 20);
            this.ReqLOB_textBox.TabIndex = 28;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(21, 135);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "Request Date/Time";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 192);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Request Summary";
            // 
            // ReviewReqSum_textBox
            // 
            this.ReviewReqSum_textBox.Location = new System.Drawing.Point(24, 208);
            this.ReviewReqSum_textBox.Multiline = true;
            this.ReviewReqSum_textBox.Name = "ReviewReqSum_textBox";
            this.ReviewReqSum_textBox.Size = new System.Drawing.Size(465, 254);
            this.ReviewReqSum_textBox.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(21, 103);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Request Title";
            // 
            // ReviewUserReqTitle_textBox
            // 
            this.ReviewUserReqTitle_textBox.Location = new System.Drawing.Point(132, 97);
            this.ReviewUserReqTitle_textBox.Name = "ReviewUserReqTitle_textBox";
            this.ReviewUserReqTitle_textBox.Size = new System.Drawing.Size(357, 20);
            this.ReviewUserReqTitle_textBox.TabIndex = 22;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(298, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "LOB";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 66);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "User Login Name";
            // 
            // ReviewUserNm_textBox
            // 
            this.ReviewUserNm_textBox.Location = new System.Drawing.Point(132, 62);
            this.ReviewUserNm_textBox.Name = "ReviewUserNm_textBox";
            this.ReviewUserNm_textBox.Size = new System.Drawing.Size(145, 20);
            this.ReviewUserNm_textBox.TabIndex = 18;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(941, 518);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBoxRqstDtTm
            // 
            this.textBoxRqstDtTm.Location = new System.Drawing.Point(829, 25);
            this.textBoxRqstDtTm.Name = "textBoxRqstDtTm";
            this.textBoxRqstDtTm.Size = new System.Drawing.Size(114, 20);
            this.textBoxRqstDtTm.TabIndex = 11;
            this.textBoxRqstDtTm.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.logo;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Location = new System.Drawing.Point(25, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(53, 71);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // Priority_comboBox
            // 
            this.Priority_comboBox.FormattingEnabled = true;
            this.Priority_comboBox.Items.AddRange(new object[] {
            "",
            "LOW",
            "MED",
            "HIGH"});
            this.Priority_comboBox.Location = new System.Drawing.Point(561, 42);
            this.Priority_comboBox.Name = "Priority_comboBox";
            this.Priority_comboBox.Size = new System.Drawing.Size(61, 21);
            this.Priority_comboBox.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(504, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "Priority";
            // 
            // ReqComplex_comboBox
            // 
            this.ReqComplex_comboBox.FormattingEnabled = true;
            this.ReqComplex_comboBox.Items.AddRange(new object[] {
            "",
            "LOW",
            "MED",
            "HIGH"});
            this.ReqComplex_comboBox.Location = new System.Drawing.Point(332, 162);
            this.ReqComplex_comboBox.Name = "ReqComplex_comboBox";
            this.ReqComplex_comboBox.Size = new System.Drawing.Size(66, 21);
            this.ReqComplex_comboBox.TabIndex = 51;
            // 
            // ReqPrior_comboBox
            // 
            this.ReqPrior_comboBox.FormattingEnabled = true;
            this.ReqPrior_comboBox.Items.AddRange(new object[] {
            "",
            "LOW",
            "MED",
            "HIGH"});
            this.ReqPrior_comboBox.Location = new System.Drawing.Point(132, 163);
            this.ReqPrior_comboBox.Name = "ReqPrior_comboBox";
            this.ReqPrior_comboBox.Size = new System.Drawing.Size(66, 21);
            this.ReqPrior_comboBox.TabIndex = 52;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(84, 166);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 13);
            this.label14.TabIndex = 53;
            this.label14.Text = "Priority";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(269, 167);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 54;
            this.label15.Text = "Complexity";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(995, 653);
            this.Controls.Add(this.tabSubmit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxRqstDtTm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabSubmit.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ReqComplDt_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReqStatusDt_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tabSubmit;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxRqstTitle;
        private System.Windows.Forms.ComboBox comboBoxLOB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label UserNmLabel;
        private System.Windows.Forms.TextBox textBoxUserNm;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBoxRqstDtTm;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.CheckBox CompletedCheckBox;
        private System.Windows.Forms.Button buttonRefresh;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button buttonSaveChanges;
        private System.Windows.Forms.TextBox textBoxRqstSum;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ReqSave_button;
        private System.Windows.Forms.Button ReqSearch_button;
        private System.Windows.Forms.Label RequestStatus_label;
        private System.Windows.Forms.DateTimePicker RequestStatus_dateTimePicker;
        private System.Windows.Forms.Label ReqSearchStatus_label;
        private System.Windows.Forms.Label SearchbyID_label;
        private System.Windows.Forms.TextBox ReqSearchID_textBox;
        private System.Windows.Forms.Label ReqComplDt_label;
        private System.Windows.Forms.Label ReqNotes_label;
        private System.Windows.Forms.TextBox ReqNotes_textBox;
        private System.Windows.Forms.Label ReqCompleted_label;
        private System.Windows.Forms.TextBox ReqLOB_textBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ReviewReqSum_textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ReviewUserReqTitle_textBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ReviewUserNm_textBox;
        private System.Windows.Forms.CheckBox ReqView_checkBox;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TextBox ReqUserDT_textBox;
        private System.Windows.Forms.TextBox ReqComplDt_TextBox;
        private System.Windows.Forms.Button ClearOutReq_button;
        private System.Windows.Forms.PictureBox ReqStatusDt_pictureBox;
        private System.Windows.Forms.PictureBox ReqComplDt_pictureBox;
        private System.Windows.Forms.ComboBox ReqSearchStatus_comboBox;
        private System.Windows.Forms.ComboBox ReqCompleted_comboBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox Priority_comboBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox ReqPrior_comboBox;
        private System.Windows.Forms.ComboBox ReqComplex_comboBox;
    }
}

